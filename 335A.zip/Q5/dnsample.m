function y = dnsample(x, M)
    y = x(1:M:end);
end