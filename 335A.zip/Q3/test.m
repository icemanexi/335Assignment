function [o] = test(t)
%TEST Summary of this function goes here
%   Detailed explanation goes here
o=0
if t <= 1
    o = 1
elseif t<=2
    o = 2
end

end

